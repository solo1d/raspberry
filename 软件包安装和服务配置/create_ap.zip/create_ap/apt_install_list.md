sudo apt-get install util-linux procps hostapd iproute2 iw haveged dnsmasq
